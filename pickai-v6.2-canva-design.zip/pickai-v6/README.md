# PickAI v6.2 — Canva design refresh

## What changed
- Refreshed the front end to match the supplied Canva design: dark charcoal/black background, warm orange-red accents, large hero search area, and five shopping-store cards.
- Kept the existing AI recommendation endpoint and keyword-search links for Amazon, 11st, Coupang, AliExpress, and Temu.
- The three AI-generated search directions are selectable; selecting one updates all five store links.
- Unified user-facing interface and fallback messages in polite Korean.
- Added an explicit system instruction asking the AI to use polite Korean in all user-visible explanations.

## Run locally
1. Extract this ZIP.
2. In the project folder, run `npm.cmd install`.
3. Copy `.env.example` to `.env`.
4. Put your own API key and an API model ID enabled for your account in `.env`.
5. Run `npm.cmd start`.
6. Open `http://localhost:3000`.

Do not upload `.env` to GitHub or share your API key. This ZIP intentionally does not contain a real `.env` file.

## Notes
PickAI creates search links; it does not fetch live product listings, prices, stock, or ratings. Those details are checked on the shopping sites.
